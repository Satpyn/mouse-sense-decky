# Mouse Sense for Decky

This is a small Decky plugin source project for Steam Deck / SteamOS Game Mode.

What it does:
- lets you pick a Gamescope `--mouse-sensitivity` multiplier
- optionally adds `--force-grab-cursor`
- can push the generated command into **Decky Launch Options** if that plugin is installed
- can also copy the final launch command for manual pasting into Steam launch options

## Why it works this way

There is no clean Decky-side runtime API here to patch the already running embedded Gamescope mouse sensitivity directly.
So this plugin takes the safer route: it generates a per-game launch option.

## Build

Use the current Decky plugin template workflow:

```bash
pnpm i
pnpm run build
```

After build, package the plugin folder in the standard Decky zip layout.

## Install from zip

1. Build the plugin so `dist/index.js` exists.
2. Zip the folder so the archive root contains:
   - `mouse-sense-decky/dist/index.js`
   - `mouse-sense-decky/package.json`
   - `mouse-sense-decky/plugin.json`
3. In Decky Loader settings, enable Developer Mode.
4. Use `Install Plugin from Zip`.

## Notes

- `--mouse-sensitivity` changes mouse movement itself, not just cursor speed.
- Some Gamescope versions and some games have odd dead-zone / sticky behavior with very low values.
- Reasonable starting values are usually `0.50`, `0.65`, `0.80`, or `1.00`.
